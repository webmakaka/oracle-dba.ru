---
layout: page
title:  Шаги, выполняемые после создания дупликата на Primary
permalink: /oracle-database-installation/dataguard/linux/6.7/oracle/12.1/post-duplicate-steps-on-primary/
---

# [Инсталляция Oracle Active DataGuard 12.1 в операционной системе Centos 6.7]: Шаги, выполняемые после создания дупликата на Primary


При создании дупликата, мы задали какие-то параметры на standby. Нужно сделать так, чтобы такие же параметры были и на primary.


SQL> alter system set LOG_ARCHIVE_CONFIG='DG_CONFIG=(master, slave)' scope=both;



На работающей базе мы не сможем поправить параметр log_archive_dest_1, если он задан. Поэтому только добавляем направление копирования в standby базу:

SQL> alter system set log_archive_dest_1='SERVICE=slave LGWR ASYNC VALID_FOR=(ONLINE_LOGFILES,PRIMARY_ROLE) db_unique_name=slave' scope=both;





SQL> alter system set log_archive_dest_2='LOCATION=+ARCH VALID_FOR=(ALL_LOGFILES,ALL_ROLES) db_unique_name=master' scope=both;



SQL> alter system set log_archive_dest_state_1=ENABLE scope=both;
SQL> alter system set log_archive_dest_state_2=ENABLE scope=both;

# эти параметры нам понадобятся для работы INSTANCE только в режиме STANDBY

SQL> alter system set FAL_SERVER="slave" scope=both;
SQL> alter system set FAL_CLIENT="master" scope=both;
SQL> alter system set standby_file_management= AUTO scope=both;



Посмотреть параметры:


SQL> show parameter arch
SQL> show parameter log_archive_dest_state_1




### Primary ORIG

	SQL> show parameter arch

	SQL> alter system set log_archive_dest_1='LOCATION=+ARCH VALID_FOR=(all_logfiles,all_roles) DB_UNIQUE_NAME=orcl12' scope=both;

	SQL> alter system set log_archive_dest_2='service=standby LGWR ASYNC NOAFFIRM NET_TIMEOUT=30 valid_for=(ONLINE_LOGFILE,PRIMARY_ROLE) db_unique_name=standby';
